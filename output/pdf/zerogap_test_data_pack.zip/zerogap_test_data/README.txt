ZeroGap synthetic GST test pack - September 2026

Upload sales_*.pdf under Sales -> Upload more bills.
Upload purchase_*.pdf under Purchases vs 2B -> Purchase bills.
Upload purchase_PUR-DUPLICATE-106.pdf twice to exercise duplicate detection.
All GSTINs and parties are synthetic. expected_results.json documents each intended case.
